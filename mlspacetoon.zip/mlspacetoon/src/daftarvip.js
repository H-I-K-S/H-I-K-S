const daftarvip = (prefix) => { 
	return `
	
*HARGA DAFTAR VIP :*
-Rp. ?K > Akses Fitur ViP
-Rp. ??K > Fitur VIP + Masukin Bot KeGrup Kalian!

*JIKA INGIN DAFTAR VIP :*
*Chat Owner BOT :*
wa.me/6287714745440 atau ketik *${prefix}owner*
 `
}
exports.daftarvip = daftarvip